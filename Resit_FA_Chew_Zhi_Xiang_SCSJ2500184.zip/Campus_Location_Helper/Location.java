package Campus_Location_Helper;

public class Location {

	String name, String purpose ;
	public static void main Dairy (String n,String p)
	
}
	
	{
		n=name
		p=purpose
		
	public static void main displayInfo
	{
			System.out.println("Name:")
			system.oput.println("Purpose:"+purpose);
			
	public static voiid main()
	{
		building d =new Building("Library","Study Area")
		building e =new Building ("Canteen”, “Dining Area")
		
			d.show();
			e.displayInfo();
	

	}
		
}
